
// A list of the export functions keyed by the Export menu name they should appear as:
var EXPORT_FORMATS = {

};

/*
// Examples:
var EXPORT_FORMATS = {
  "IRIDA":        {'method': exportIRIDA, 'fileType': 'xls', 'status': 'published'},
  "GISAID":       {'method': exportGISAID,'fileType': 'xls', 'status': 'published'},
  "BioSample":    {'method': exportBioSample,'fileType': 'xls', 'status': 'published'},
  "CNPHI LaSER":  {'method': exportLASER, 'fileType': 'csv (ASCII)', 'status': 'published'}
};
*/
